// Legacy (deprecated) — kept so external imports don't break.
export { BehindTheScenes, type BehindTheScenesProps } from "./BehindTheScenes";
export { ToolCallComponent, type ToolCallProps } from "./ToolCall";

// Compound primitive set + batteries-included compositions.
export { DefaultToolCard } from "./DefaultToolCard";
export { SourceIcon } from "./SourceIcon";
export { TimelineToolCard } from "./TimelineToolCard";
export { ToolCall, defaultLabel, prettyResult, toolIcon, useToolCall } from "./ToolCallPrimitives";
export { ToolCallTimeline, type TimelineStep } from "./ToolCallTimeline";
export { extractToolSources, type ToolResultSource } from "./toolSources";
