export * from "./ImageTextLarge";
